#!/bin/bash

~/cp2k-9.1/exe/local/cp2k.sopt -i ./main_Cl_water_5kbar_dp_BM.inp > ./main.out
